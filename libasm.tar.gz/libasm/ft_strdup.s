; char	*ft_strdup(const char *s1);

%ifdef __MACH__
	%define FUNC(name)  _%+name
%else
    %define FUNC(name)  name
%endif

section .text
	global FUNC(ft_strdup)
    extern FUNC(ft_strlen)              ; 외부 함수 사용
    extern FUNC(ft_strcpy)              ; 외부 함수 사용
    extern FUNC(malloc)                 ; 외부 함수 사용

FUNC(ft_strdup):
    push    rbp                         ; 스택을 사용하기 위해 이전 함수의 프레임 포인터(스택의 시작 지점)를 저장 => calle-saved(rbp)
    mov     rbp, rsp                    ; 현재 스택의 시작 지점을 프레임 포인터를 저장
    sub     rsp, 8                      ; 스택에 8바이트를 할당(스택 포인터: 스택의 끝 지점)
    mov     qword [rsp], rdi            ; 첫 번째 인자를 스택에 복사 => callee-saved(rdi)
    call    FUNC(ft_strlen)             ; 문자열 길이를 세기 위해 ft_strlen 함수 호출
    inc     rax                         ; 널 문자용 길이 1 추가
    mov     rdi, rax                    ; malloc의 첫 번째 인자에 복사
    call    FUNC(malloc)                ; 동적 할당을 위한 malloc 함수 호출
    cmp     rax, 0                      ; malloc 함수 반환 값 NULL 체크
    je      null_guard                  ; NULL이라면 null_guard로 점프
    mov     rdi, rax                    ; dst를 첫 번째 인자에 복사
    mov     rsi, qword [rsp]            ; src를 두 번째 인자에 복사
    call    FUNC(ft_strcpy)             ; 문자열 복사를 위한 ft_strcpy 함수 호출
    jmp     done                        ; done으로 점프

null_guard:
    xor     rax, rax                    ; 반환 값을 NULL 포인터로 지정
    jmp     done                        ; done으로 점프

done:
    mov     rsp, rbp                    ; 사용하던 스택 포인터를 프레임 포인터(스택의 시작 지점)로 옮김
    pop     rbp                         ; rbp 크기(8바이트) 만큼 rsp를 증가
    ret                                 ; 호출자에게 반환(리턴 주소로 복귀, 위와 같이 rsp 증가)