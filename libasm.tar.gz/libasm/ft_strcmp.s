; int		ft_strcmp(const char *s1, const char *s2);

%ifdef __MACH__
	%define FUNC(name)  _%+name
%else
    %define FUNC(name)  name
%endif

section .text
	global FUNC(ft_strcmp)

FUNC(ft_strcmp):
    xor     rcx, rcx                    ; rcx를 초기화
    xor     rdx, rdx                    ; rdx를 초기화

loop:
	mov     cl, byte [rdi]		        ; rdi 주소에서 1바이트만 rcx 하위 1바이트(cl)에 복사
	mov     dl, byte [rsi]  	        ; rsi 주소에서 1바이트만 rdx 하위 1바이트(dl)에 복사
    inc     rsi					        ; 주소 1 증가
	inc     rdi					        ; 주소 1 증가
    cmp     cl, dl                      ; 1바이트 비교
    je      is_zero                     ; 같을 경우, is_zero로 점프
    jne     done                        ; 같지 않을 경우, done으로 점프

is_zero:
    cmp     cl, 0                       ; cl과 0을 비교(둘 다 0인 경우)
    je      done                        ; 같을 경우, done으로 점프
    jne     loop                        ; 같지 않을 경우, done으로 점프

; cl - dl로 저장하면 오버플로우 발생
done:
    mov     rax, rcx                    ; 반환 값에 cl을 복사
    sub     rax, rdx                    ; 반환 값에서 dl을 차감
	ret							        ; 호출자에게 반환(리턴 주소로 복귀)