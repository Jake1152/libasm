; char	*ft_strcpy(char *dst, const char *src);

%ifdef __MACH__
	%define FUNC(name)	_%+name
%else
	%define FUNC(name)	name
%endif

section .text
	global FUNC(ft_strcpy)

FUNC(ft_strcpy):
	mov     rcx, rdi					; 시작 주소를 저장

loop:
	; mov [rdi], [rsi] 처럼 사용하지 못함 => 두 개의 피연산자에서 메모리 주소를 동시에 사용하는 메모리 간 직접 복사 명령어가 없기 때문
	mov     dl, byte [rsi]				; rsi를 참조한 값에서 1바이트만 복사
	mov     byte [rdi], dl				; rdi가 가리키는 주소에 1바이트를 복사
	inc     rsi							; 주소 1바이트 증가
	inc     rdi							; 주소 1바이트 증가
	cmp     dl, 0						; 복사한 값이 0과 같은지 검사
	je      done						; 같다면 done으로 점프
	jmp     loop						; 다르다면 loop로 점프

done:
	mov     rax, rcx					; 시작 주소를 반환하기 위해 복사
	ret									; 호출자에게 반환(리턴 주소로 복귀)