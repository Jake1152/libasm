; size_t  ft_strlen(const char *str);

%ifdef __MACH__
	%define FUNC(name)  _%+name
%else
    %define FUNC(name)  name
%endif

section .text
    global FUNC(ft_strlen)

FUNC(ft_strlen):
    xor     rax, rax                    ; 0으로 초기화

loop:
    cmp     byte [rdi], 0               ; rdi의 참조값과 0을 비교
    je      done                        ; 동일하다면 done으로 점프
    inc     rax                         ; 결과값 1 증가
    inc     rdi                         ; rdi 주소 1 증가
    jmp     loop                        ; loop의 처음으로 점프

done:
    ret                                 ; 호출자에게 반환