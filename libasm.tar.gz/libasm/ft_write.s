; ssize_t ft_write(int fildes, const void *buf, size_t nbyte);

%ifdef __MACH__
	%define FUNC(name)          _%+name
    %define ERRNO_LOCATION      __error
    %define SYSTEM_CALL_NUMBER  0x2000004

%else
    %define FUNC(name)          name
    %define ERRNO_LOCATION      __errno_location
    %define SYSTEM_CALL_NUMBER  1
%endif

section .text
    global FUNC(ft_write)
    extern FUNC(ERRNO_LOCATION)         ; errno의 주소를 리턴하는 외부 함수 사용

FUNC(ft_write):
    push    rbp                         ; 스택을 사용하기 위해 이전 함수의 프레임 포인터(스택의 시작 지점)를 저장 => calle-saved(rbp)
    mov     rbp, rsp                    ; 현재 스택의 시작 지점을 프레임 포인터를 저장
    sub     rsp, 8                      ; 스택에 8바이트를 할당(스택 포인터: 스택의 끝 지점)
    mov     rax, SYSTEM_CALL_NUMBER     ; write 시스템 콜 번호
    syscall                             ; write 시스템 콜 호출
%ifdef __MACH__
	jc      set_error           		; mac) 시스템 콜 실패 시 carry flag가 설정되고 rax에 errno 반환. carry flag를 확인하여, set_error로 점프
%else
	cmp		rax, 0                      ; linux) 시스템 콜 실패 시 rax애 -errno를 반환. rax와 0을 비교
	jl		set_error                   ; 음수라면 done으로 점프
%endif
    jmp     done                        ; 0 이상이라면 done으로 점프

set_error:
%ifndef __MACH__
	neg		rax							; linux) errno를 얻기 위해 -1을 곱함
%endif
    mov     qword [rsp], rax            ; 스택에 errno를 push => caller-saved(rax)
    call    FUNC(ERRNO_LOCATION)        ; errno의 주소를 반환하는 외부 함수를 호출
    mov     rdx, qword [rsp]            ; rsp 부터 qword(8바이트) 만큼 값을 읽어 rdx로 복사
    mov     [rax], rdx                  ; rdx를 rax(errno의 주소) 참조 메모리에 복사
    mov     rax, -1                     ; 반환하기 위해 -1을 할당
    jmp     done                        ; done으로 점프

done:
    mov     rsp, rbp                    ; 사용하던 스택 포인터를 프레임 포인터(스택의 시작 지점)로 옮김
    pop     rbp                         ; rbp 크기(8바이트) 만큼 rsp를 증가
    ret                                 ; 호출자에게 반환(리턴 주소로 복귀, 위와 같이 rsp 증가)